#include "pmj0049Project2_header.h"

void add_Student () {
  ifstream fin; 
  ofstream fout;
  Student student;
  fout.open ("student.dat", ofstream::app); //so the file is not overwritten
  string temp;

  //get information from the user
  cout << "Please enter the last name of the student: ";
  cin >> student.name;
  cout <<"Please enter the first name of the student: ";
  cin >> temp;
  student.name = student.name + "," + temp;
  cout << "Please enter the student ID: ";
  cin >> student.studentID;
  cout << "How many tests did this student take: ";
  cin >> student.numTests;

  student.testScores = new int [student.numTests]; //create dynamic array

  for (int i = 0; i < student.numTests; ++i) {
    cout << "Please enter score #" << i+1 << ": ";
    cin >> *(student.testScores+i);
  } //get the user defined array of student scores

  fout << endl; 
  fout << student.name << ",";
  fout << student.studentID << ",";
  fout << student.numTests << ",";
  for (int i = 0; i < student.numTests; ++i) {
  fout << *(student.testScores + i) << ",";
  } //print values to file
  fout.close ();
  delete [] student.testScores; //close file and free dynamic memory
}

  void remove_Student (long int studentID) { //studentID parameter
  ifstream fin; 
  ofstream fout;
  Student student;
  int numStudents;
  int i = 0;
  int lineNum;
   //create pointer for student structure
  string line; 
  bool idMatch = false;
  stringstream studentStream; //user sstream
  
  numStudents = getNumber(); //use getNumber function to get number of lines 
  
  Student* dynArray = new Student [numStudents];

  fin.open ("student.dat");
   
  for (int i = 0; i < numStudents; ++i) { //read the whole file 
    getline(fin, line);
    studentStream << line;
    string temp;
    if (line.empty())
        break;
 
    
    getline(studentStream, dynArray[i].name, ',');  //the comma operator allows the program to get the string until the first comma
    getline(studentStream, temp, ','); // get the last name
    
    dynArray[i].name = dynArray [i].name + "," + temp; //merge the two strings
    getline(studentStream, temp, ','); //get the string of the studentID
    dynArray[i].studentID = stol(temp); //convert the studentID string into a long integer
    getline(studentStream, temp, ','); //repeat the same process detailed above for numTests
    dynArray[i].numTests = stoi(temp);
    dynArray[i].testScores = new int [dynArray[i].numTests]; //dynamic array for testScores
    
    
    for (int j = 0; j < dynArray[i].numTests; ++j) {
      getline(studentStream, temp, ',');
      dynArray[i].testScores[j] =  stoi(temp); //string testScores to integer
   }
    
    ++i;
  }
  for (int i = 0; i < numStudents; ++i) {
    if (studentID == dynArray[i].studentID) { //check if the id's are the same
      idMatch = true;
      lineNum = i;
    }
  }
  fin.close();
  if (idMatch) {
    fout.open ("student.dat");
    for (int i = 0; i < numStudents; ++i) {
      if (i != lineNum) { //remove the line in question
        fout << dynArray[i].name << ",";
        fout << dynArray[i].studentID << ",";
        fout << dynArray[i].numTests << ",";
        for (int j = 0; j < dynArray[i].numTests; ++j) {
          fout << dynArray[i].testScores[j] << ",";
        }
        if (i < numStudents-1) {
          fout << endl;
        }
      }
    }
  }
  else {
    cout << "Sorry, but the ID entered does not match an ID in the database." << endl;
  }
  fout.close();
  delete [] dynArray;
}

void display () {
  ifstream fin; 
  ofstream fout;
  Student student;
  int lineNum;
  int i = 0;
  string line;
  lineNum = getNumber();
  stringstream studentStream;
  Student* dynArray = new Student [lineNum]; //dynamic array
  fin.open ("student.dat");
  while (!fin.eof() && fin.good()) { //same process as above for entering the data elements into array
    getline(fin, line);
    studentStream << line;
    if (line.empty())
        break;
 
    string temp;
    getline(studentStream, dynArray[i].name, ',');
    getline(studentStream, temp, ',');
    
    dynArray[i].name = dynArray [i].name + "," + temp;
    getline(studentStream, temp, ',');
    dynArray[i].studentID = stol(temp);
    getline(studentStream, temp, ',');
    dynArray[i].numTests = stoi(temp);
    dynArray[i].testScores = new int [dynArray[i].numTests];
    
    
    for (int j = 0; j < dynArray[i].numTests; ++j) {
      getline(studentStream, temp, ',');
      dynArray[i].testScores[j] =  stoi(temp);
   }
    
    ++i;
  }
  
  for (int i = 0; i < lineNum; ++i) {
    cout << setw(30) << dynArray[i].name; //display the results with a certain amount of space allocated
    cout << setw(15) << dynArray[i].studentID;
  for (int j = 0; j < dynArray[i].numTests; ++j) {
    cout << setw(5) << dynArray[i].testScores[j];
  }
  cout << endl;
  }
  fin.close();
  
  delete [] dynArray;
}

void search (long int studentID) {
  ifstream fin; 
  ofstream fout;
  Student student;
  fin.open ("student.dat");
  Student* info = new Student [1]; //declare and intialize info pointer
  int numLines;
  string temp;
  string line;
  stringstream studentStream;
  bool idMatch = false;
  
  while (!fin.eof() && fin.good()) { //get the elements into the student structure pointer
    getline(fin, line);
    studentStream << line;
    if (line.empty())
        break;
 
    string temp;
    getline(studentStream, info->name, ',');
    getline(studentStream, temp, ',');
    
    info->name = info->name + "," + temp;
    getline(studentStream, temp, ',');
    info->studentID = stol(temp);
    getline(studentStream, temp, ',');
    info->numTests = stoi(temp);
    info->testScores = new int [info->numTests];
    
    
    for (int j = 0; j < info->numTests; ++j) {
      getline(studentStream, temp, ',');
      info->testScores[j] =  stoi(temp);
   }
    if (studentID == info->studentID) {      
      idMatch = true;
      break; //break out of loop when the match is found
    }
    
    
  }
  if (idMatch) {
  cout << setw(30) << info->name; //print out the oine where the match was found
  cout << setw(15) << info->studentID;
  for (int j = 0; j < info->numTests; ++j) {
    cout << setw(5) << info->testScores[j];
  }
  cout << endl;
  }
  else {
      cout << "There is no match for the ID requested." << endl;
  }
  fin.close();
  delete [] info->testScores;
}

void exportResults () {
  ifstream fin; 
  ofstream fout;
  Student student;
  int lineNum;
  int testSum = 0;
  double avgScore;
  int i = 0;
  string line;
  lineNum = getNumber();
  stringstream studentStream;
  Student* dynArray = new Student [lineNum];
  fin.open ("student.dat");
  fout.open ("averages.dat"); //create a new file to write the average scores of each student
  while (!fin.eof() && fin.good()) { //get the elements of the file into a dynamic array
    getline(fin, line);
    studentStream << line;
    if (line.empty())
        break;
 
    string temp;
    getline(studentStream, dynArray[i].name, ',');
    getline(studentStream, temp, ',');
    
    dynArray[i].name = dynArray [i].name + "," + temp;
    getline(studentStream, temp, ',');
    dynArray[i].studentID = stol(temp);
    getline(studentStream, temp, ',');
    dynArray[i].numTests = stoi(temp);
    dynArray[i].testScores = new int [dynArray[i].numTests];
    
    
    for (int j = 0; j < dynArray[i].numTests; ++j) {
      getline(studentStream, temp, ',');
      dynArray[i].testScores[j] =  stoi(temp);
   }
    
    ++i;
  }

  for (i = 0; i < lineNum; ++i) {
    for (int j=0; j < dynArray[i].numTests; ++j) {
    testSum += dynArray[i].testScores[j]; //compute the sum of all the test score values
  }
    testSum = testSum - findMinimum(dynArray[i].testScores, dynArray[i].numTests); //subtract the minimum value from the testscores sum
    if (dynArray[i].numTests < 5)
      dynArray[i].testAvg = static_cast<double>(testSum)/(dynArray[i].numTests); //divide by normal number of tests if the minimum score is 0
    else
      dynArray[i].testAvg = static_cast<double>(testSum)/(dynArray[i].numTests -1); //divide by one less test if minimum is subtracting
    fout << dynArray[i].studentID << " ";
    fout << fixed << setprecision (1) << dynArray[i].testAvg << endl;
    testSum = 0;
    dynArray[i].testAvg = 0;
  }
  fin.close();
  fout.close();
  delete [] dynArray;
}

int findMinimum (int testsArray[], int numTests) {
  int min;
  min = testsArray [0];
  if (numTests < 5) {
    min = 0;
  }
  else {
    for (int i =0; i < numTests; ++i) { //find minimum of the array
      if (testsArray[i] < min) {
        min = testsArray [i];
      }
    }
  }
  return min;
}
#include "pmj0049Project2_header.h"

int main() {
  ifstream fin; 
  ofstream fout;
  Student student;
  int menuOpt;
  cout << "+-------------------------------------------------+" << endl;
  cout << "|          Computer Science and Engineering       |" << endl;
  cout << "|           CSCE 1030 - Computer Science I        |" << endl;
  cout << "|            Paarth Jamdagneya pmj0049            |" << endl;
  cout << "|            paarthjamdagneya@my.unt.edu          |" << endl;
  cout << "+-------------------------------------------------+" << endl;

  
  //use for loop to continue asking user for the input until it is valid
  do { //display the menu for the user
  cout << "1. Add" << endl;
  cout << "2. Remove" << endl;
  cout << "3. Display" << endl;
  cout << "4. Search" << endl;
  cout << "5. Results" << endl;
  cout << "6. Quit" << endl;
  cout << "Enter choice: ";
  cin >> menuOpt;
  menuOpt = static_cast<menuOptions> (menuOpt);
  switch (menuOpt) { //switch case to get the different options for the user

    case Add:
      add_Student (); //call function
      
      break;
    
    case Remove:
      cout << "Please enter the ID of the student which you want to remove: ";
      cin >> student.studentID;
      remove_Student (student.studentID); //call function
      
      break;

    case Display:
      display(); //call function
      
      break;

    case Search:
      cout << "What is the ID of the student to search for: ";
      cin >> student.studentID;
      search (student.studentID); //call function
      
      break;
    
    case Results:
      exportResults (); //call function
      
      break;
    
    case Quit:
      cout << "Thanks." << endl;
      exit (1);

    default:
      cout << "Please enter a proper choice." << endl;
  }
} while (menuOpt != Quit);

return 0;
}


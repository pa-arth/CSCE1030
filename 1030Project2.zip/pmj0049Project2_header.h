#include <iostream>

#include <sstream>

#include <iomanip>

#include <fstream>

#include <string>

#ifndef PMJ0049PROJECT2_HEADER_CPP
#define PMJ0049PROJECT2_HEADER_CPP

using namespace std;

const int NUMTESTS = 5; 

enum menuOptions {Add = 1, Remove = 2, Display, Search, Results, Quit};

struct Student {
  string name;
  long int studentID;
  int numTests;
  int* testScores = new int;
  double testAvg;
};

void add_Student ();
void remove_Student (long int studentID);
void display ();
void search (long int studentID);
void exportResults ();
int findMinimum (int testScores [5], int NUMTESTS);
int getNumber ();


#endif